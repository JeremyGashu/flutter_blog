import 'package:equatable/equatable.dart';

class PreprocessorEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class LoadPreprocessor extends PreprocessorEvent {}
