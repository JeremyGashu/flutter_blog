class WidgetType {
  static const String header = 'header'; //donw
  static const String paragraph = 'paragraph'; //done
  static const String list = 'list'; //done
  static const String delimter = 'delimiter'; //done
  static const String image = 'image'; //done
  static const String code = 'code'; //done
  static const String quote = 'quote'; //done
  static const String table = 'table'; //done
  static const String rawTool = 'rawTool'; //done
  static const String linkTool = 'linkTool'; //done
  static const String video = 'video'; //done
}