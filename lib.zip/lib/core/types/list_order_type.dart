class ListOrderType {
  static String get alphabetical => 'alphabetical';
  static String get numerical => 'numerical';
  static String get roman => 'roman';
}
