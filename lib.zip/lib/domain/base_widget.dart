import 'package:equatable/equatable.dart';

abstract class BaseWidgetModel extends Equatable {}
